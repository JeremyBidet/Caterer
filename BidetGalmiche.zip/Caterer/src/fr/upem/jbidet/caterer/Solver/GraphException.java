package fr.upem.jbidet.caterer.Solver;

public class GraphException extends Exception {
	
	private static final long serialVersionUID = -4959287292157882763L;

	public GraphException() {
	}

	public GraphException(String arg0) {
		super(arg0);
	}

	public GraphException(Throwable arg0) {
		super(arg0);
	}

	public GraphException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public GraphException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

}
