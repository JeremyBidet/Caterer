Projet Caterer
==============

Nom constituant le bin�me
-------------------------

- BIDET J�r�my
- GALMICHE M�lody


Modalit� de compilation
-----------------------

Pour compiler le programme, il est recommand� d'utiliser un IDE comme Eclipse.

En ligne de commande il est toujours possible de compiler.
Se placer dans le package racine fr.upem.jbidet.caterer et lancer la commande :
    $ javac Core/*.java DAO/*.java Solver/*.java Main.java


Execution du programme
----------------------

Il est recommand� d'utiliser encore un IDE (Eclipse) pour ex�cuter le programme.
S�lectionner le projet et lancer la commande Run.

Sinon, apr�s compilation lancer la commande :
    $ java Main.class
l� o� le fichier MAin.class a �t� cr�� apr�s compilation
